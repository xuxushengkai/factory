package com.sjj.factory.abstractFacotry;

/**
 * @ClassName HuaWeiFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:19
 * @Version 1.0
 **/
public class HuaWeiFactory implements  PhoneFactory {
    @Override
    public IVideo createMusic() {
        return new HuaWeiVideoFactory();
    }

    @Override
    public IMusic createVideo() {
        return new HuaWeiMusicFactory();
    }
}

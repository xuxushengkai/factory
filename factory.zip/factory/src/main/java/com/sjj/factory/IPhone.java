package com.sjj.factory;

public interface IPhone {
    void point();
}

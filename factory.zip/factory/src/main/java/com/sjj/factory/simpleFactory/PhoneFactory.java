package com.sjj.factory.simpleFactory;

import com.sjj.factory.IPhone;

/**
 * @ClassName PhoneFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 10:06
 * @Version 1.0
 **/
public class PhoneFactory {
    public IPhone create(Class<? extends IPhone> clazz){
        if(null != clazz){
            try {
                return clazz.newInstance();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}

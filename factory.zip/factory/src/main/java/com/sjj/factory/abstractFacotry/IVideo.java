package com.sjj.factory.abstractFacotry;

/**
 * @ClassName ICall
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:03
 * @Version 1.0
 **/
public interface IVideo {
    void look();
}

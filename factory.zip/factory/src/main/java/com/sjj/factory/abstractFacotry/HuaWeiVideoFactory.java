package com.sjj.factory.abstractFacotry;

/**
 * @ClassName HuaWeiVideoFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:18
 * @Version 1.0
 **/
public class HuaWeiVideoFactory implements IVideo {
    @Override
    public void look() {
        System.out.println("华为手机，视频流畅");
    }
}

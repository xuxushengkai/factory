package com.sjj.factory.factoryMehtod;

import com.sjj.factory.IPhone;

public interface IphoneFactory {
     IPhone create();
}

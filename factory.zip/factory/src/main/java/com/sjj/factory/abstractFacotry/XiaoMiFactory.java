package com.sjj.factory.abstractFacotry;


/**
 * @ClassName XiaoMiFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:12
 * @Version 1.0
 **/
public class XiaoMiFactory implements PhoneFactory {
    @Override
    public IVideo createMusic() {
        return new XiaoMiVideoFactory();
    }

    @Override
    public IMusic createVideo() {
        return new XiaoMiMusicFactory();
    }
}

package com.sjj.factory.simpleFactory;

import com.sjj.factory.IPhone;
import com.sjj.factory.XiaoMiPhone;

/**
 * @ClassName SimpleTest
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 10:41
 * @Version 1.0
 **/
public class SimpleTest {
    public static void main(String[] args) {
        PhoneFactory factory = new PhoneFactory();
        IPhone iPhone =  factory.create(XiaoMiPhone.class);
        iPhone.point();
    }
}

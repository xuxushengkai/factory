package com.sjj.factory.abstractFacotry;

public interface PhoneFactory {
    IVideo createMusic();

    IMusic createVideo();
}

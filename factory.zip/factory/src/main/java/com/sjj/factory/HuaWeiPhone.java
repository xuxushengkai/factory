package com.sjj.factory;

/**
 * @ClassName HuaiWeiPhone
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 10:35
 * @Version 1.0
 **/
public class HuaWeiPhone implements IPhone {

    @Override
    public void point() {
        System.out.println("华为手机功能强");
    }
}

package com.sjj.factory.factoryMehtod;

import com.sjj.factory.IPhone;
import com.sjj.factory.XiaoMiPhone;

/**
 * @ClassName XiaoMiFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 10:50
 * @Version 1.0
 **/
public class XiaoMiFactory implements IphoneFactory {
    @Override
    public IPhone create() {
        return new XiaoMiPhone();
    }
}

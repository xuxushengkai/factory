package com.sjj.factory.abstractFacotry;

public interface IMusic {
    void listen();
}

package com.sjj.factory.abstractFacotry;

/**
 * @ClassName XiaoMiVideoFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:15
 * @Version 1.0
 **/
public class XiaoMiVideoFactory implements IVideo {
    @Override
    public void look() {
        System.out.println("小米视频，比较清晰");
    }
}

package com.sjj.factory.abstractFacotry;

/**
 * @ClassName AbstractFactoryTest
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:20
 * @Version 1.0
 **/
public class AbstractFactoryTest {
    public static void main(String[] args) {
        HuaWeiFactory factory = new HuaWeiFactory();

        factory.createMusic().look();
        factory.createVideo().listen();
    }
}

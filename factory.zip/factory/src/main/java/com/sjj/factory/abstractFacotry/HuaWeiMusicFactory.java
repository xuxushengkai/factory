package com.sjj.factory.abstractFacotry;

/**
 * @ClassName HuaWeiMusicFactory
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 11:17
 * @Version 1.0
 **/
public class HuaWeiMusicFactory implements IMusic {
    @Override
    public void listen() {
        System.out.println("华为音乐，音质杠杠的");
    }
}

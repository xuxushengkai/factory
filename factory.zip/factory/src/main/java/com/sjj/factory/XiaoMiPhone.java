package com.sjj.factory;

/**
 * @ClassName XiaoMiPhone
 * @Description TODO
 * Author Admin
 * Date 2019/3/11 10:34
 * @Version 1.0
 **/
public class XiaoMiPhone implements IPhone {

    @Override
    public void point() {
        System.out.println("小米手机爱发烫");
    }
}
